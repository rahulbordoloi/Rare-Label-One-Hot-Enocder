Change Log
==========

0.0.1 (2/11/2020)
-------------------
-  First Release (Initial)
*  Top Labeled Entries Functionality
*  Rare Label One-Hot Encoder


